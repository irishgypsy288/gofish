# Update Instructions - Go Fish GUI v1.1

## Overview
This update makes the AI vs AI gameplay watchable by adding delays between turns and improving the UI layout.

## Changes Summary
- **2-second delay** between AI turns for watchable gameplay
- **Slower animations** (1 second instead of 0.5 seconds)
- **Smaller game log** (6 lines instead of 10)
- **Enhanced visual feedback** for book formations

## Building the Updated Version

### Prerequisites
Ensure you have the required dependencies:
```bash
sudo apt-get update
sudo apt-get install -y build-essential libx11-dev
```

### Build Steps
1. Navigate to the project directory:
   ```bash
   cd gofish
   ```

2. Clean previous build artifacts:
   ```bash
   make clean
   ```

3. Build the updated GUI version:
   ```bash
   make
   ```

4. Run the application:
   ```bash
   ./gofish-gui
   ```

## What to Expect

### Gameplay Experience
- When you click "NEW GAME", the AI players will start playing
- Each AI turn will be visible for 2 seconds before the next action
- Card movements will be smooth and easy to follow
- The game log will show recent actions in a compact format
- Book formations will be highlighted with "***" markers

### Timing Details
- **Turn Delay**: 2.0 seconds between each AI action
- **Animation Duration**: 1.0 second for card movements
- **Total Time per Turn**: ~3 seconds (2s delay + 1s animation)

### UI Layout
- **Top**: AI2 (Opponent) with cards face-down and book count
- **Middle**: Compact game log (6 most recent actions) and draw pile
- **Bottom**: AI1 (Current Player) with cards face-down and book count

## Customizing the Speed

If you want to adjust the gameplay speed, you can modify these values in `src/UIManager.cpp`:

### Turn Delay (line ~18)
```cpp
m_turnDelay(2.0f)  // Change this value (in seconds)
```
- Increase for slower gameplay (e.g., 3.0f for 3 seconds)
- Decrease for faster gameplay (e.g., 1.0f for 1 second)

### Animation Speed (line ~267)
```cpp
anim.progress += deltaTime * 1.0f;  // Change the multiplier
```
- Decrease multiplier for slower animations (e.g., 0.5f)
- Increase multiplier for faster animations (e.g., 2.0f)

After making changes, rebuild with:
```bash
make clean && make
```

## Troubleshooting

### Build Errors
If you encounter build errors:
1. Ensure all dependencies are installed
2. Check that you're in the `gofish` directory
3. Try `make clean` before building again

### Display Issues
If the window doesn't appear:
1. Ensure X11 is running (`echo $DISPLAY` should show a value)
2. Check that libx11-dev is installed
3. Try running from a terminal with X11 forwarding enabled

### Game Runs Too Fast/Slow
- Adjust `m_turnDelay` in `src/UIManager.cpp` as described above
- Rebuild the application after changes

## Reverting Changes

If you need to revert to the original version:
1. Use git to checkout the previous version:
   ```bash
   git checkout HEAD~1 src/UIManager.h src/UIManager.cpp
   ```

2. Rebuild:
   ```bash
   make clean && make
   ```

## Additional Resources
- See `CHANGELOG.md` for detailed technical changes
- See `README_GUI.md` for general usage instructions
- See `PROJECT_SUMMARY.md` for architecture overview